SELECT -- *
       f.flight_number, /*например, значение вида 'SU 1408'*/
       c.name,
       c1.name

	FROM flights.flight f
	JOIN flights.city c on f.from = c.label
	JOIN flights.flight f1 on f.idflight = f1.idflight
	JOIN flights.city c1 on f1.to = c1.label;