/*если в таблице orders есть данные, то делаю INNER JOIN. 
Если выборкаданные не вернет строк, то значит никто из указанных пользователей не сделал заказ*/
SELECT * FROM example.users u
JOIN example.orders o on u.id = o.user_id;

/*т.к. таблица orders не наполнена данными, сделаю LEFT JOIN, чтобы удостовериться, что не накосячила*/
SELECT * FROM example.users u
LEFT JOIN example.orders o on u.id = o.user_id;

/*смотрю товары каких категорий есть в магазине*/
SELECT p.name product,
       c.name category
FROM example.products p
JOIN example.catalogs c on p.catalog_id = c.id;

/*смотрю в каких категориях товаров в магазине нет*/
SELECT p.name product,
       c.name category
FROM example.products p
right JOIN example.catalogs c on p.catalog_id = c.id;