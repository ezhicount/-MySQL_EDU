/*
Пусть в таблице users поля created_at и updated_at оказались незаполненными. 
Заполните их текущими датой и временем.
*/
update vk_1.user set 
 user.updated_at = now(),
 user.created_at = now()
 where 1=1
 and user.updated_at is null 
 and user.created_at is null
 -- and id in (10, 11)
 ;
