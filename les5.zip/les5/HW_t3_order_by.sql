SELECT p.* 
FROM vk_1.storehouses_products p
order by value = 0, value
