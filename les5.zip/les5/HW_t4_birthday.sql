SELECT * 

FROM vk_1.user u, 
	vk_1.profile p
where 1=1
and u.id = p.user_id
and birthday like '%-05-%'
or  birthday like '%-08-%'

;