SELECT * 
FROM vk_1.like
WHERE user_id in (5, 1, 2, 6, 16)
ORDER BY FIELD (user_id, 6, 1, 2, 16);
