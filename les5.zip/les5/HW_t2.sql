/*
Таблица users была неудачно спроектирована. 
Записи created_at и updated_at были заданы типом VARCHAR 
и в них долгое время помещались значения в формате 20.10.2017 8:10. 
Необходимо преобразовать поля к типу DATETIME, сохранив введённые ранее значения.

Сделала для updated_at (для created_at аналогично)
*/

-- преобразую строки, у которых часы больше 2-знаков
update vk_1.user set 
updated_at = 
(select CONCAT ((LEFT (t.updated_at, 11)), (RIGHT (t.updated_at, 5)), ':00') 
   from (select *  FROM vk_1.user) as t
    where t.id !=0
    and t.id = user.id)
 where LENGTH(user.updated_at) = 16;

-- преобразую строки, у которых часы меньше 2-знаков
update vk_1.user set 
updated_at = 
(select CONCAT ((LEFT (t.updated_at, 11)), '0', (RIGHT (t.updated_at, 4)), ':00') 
   from (select *  FROM vk_1.user) as t
    where t.id !=0
    and t.id = user.id)
 where LENGTH(user.updated_at) = 15;

update  vk_1.user set updated_at = str_to_date(updated_at, '%d.%m.%Y %h:%i:%s')
where updated_at is not null; 
 
-- преобразую колонку в datetime
Alter table vk_1.user modify column updated_at datetime; 